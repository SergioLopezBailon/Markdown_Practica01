package swing_c_p02_LopezBailonSergio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ventana v = new Ventana();
	}

}
