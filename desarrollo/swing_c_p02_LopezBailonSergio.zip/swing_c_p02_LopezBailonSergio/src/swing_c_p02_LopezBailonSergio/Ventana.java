package swing_c_p02_LopezBailonSergio;

/*
 * @author Sergio
 */

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.text.MaskFormatter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.util.*;


public class Ventana extends JFrame{
	//Campos de la clase
	
	JDialog d;
	JMenuBar menu;
	JMenu archivo, registro, ayuda;
	JMenuItem salir, alta, baja, acerca;
	JPanel panel1, panel2, panel3, panel4, panel5, Ppanel1, Ppanel2;
	JLabel titulo, lnombre, lapellidos, lf_entrada, lf_salida, ln_dias, ltlf, ldni, ltipo, lhabitaciones, ledad, lnino, lextras, limporte, lim1, lim2, lim3, imagenes;
	JTextField nombre,apellidos,f_entrada,f_salida,n_dias,extras,importe;
	JFormattedTextField tlf,dni;
	JComboBox<String> tipo;
	JSpinner n_habitaciones, edad_nino;
	JCheckBox nino;
	JButton btnAlta, btnBaja, imprimir, nuevo, guardar;
	JTabbedPane tab;
	
	Dimension size;
	/*
	 * Constructor de la clase Ventana
	 */
	public Ventana() {
		super("Gesti�n Hotel Guadix");
		size = Toolkit.getDefaultToolkit().getScreenSize();
		
		
		setSize(size.width/2, size.height/2);
		setLocationRelativeTo(null);
		
		menu();
		
		setLayout(new FlowLayout(FlowLayout.CENTER));
		btnAlta = new JButton("Alta reservas");
		btnAlta.setMnemonic(KeyEvent.VK_A);
		btnAlta.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ventanaModal();
				
			}
		});
		btnBaja = new JButton("Baja reservas");
		btnBaja.setMnemonic(KeyEvent.VK_B);
		btnBaja.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"Opci�n todav�a en desarrollo.","Error." ,JOptionPane.WARNING_MESSAGE);				
			}
		});
		
		add(btnAlta);
		add(btnBaja);
		setVisible(true);
	}
	
	
	
	
	/*
	 * Metodo que crea la primera ventana.
	 */
	private void menu() {
		menu = new JMenuBar();
		archivo = new JMenu("Archivo");
		registro = new JMenu("Registro");
		ayuda = new JMenu("Ayuda");
		
		salir = new JMenuItem("Salir");
		salir.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
				
			}
		});
		alta = new JMenuItem("Alta Reservas");
		alta.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				ventanaModal();
			}
		});
		
		baja = new JMenuItem("Baja Reservas");
		baja.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"Opci�n todav�a en desarrollo.","Error." ,JOptionPane.WARNING_MESSAGE);
				
			}
		});
		
		acerca = new JMenuItem("Acerca de...");
		acerca.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Aplicaci�n desarrollada por Sergio Lopez Bail�n. Nombre de la empresa: "
						+ "Guadix Hoteles");
				
			}
		});
		
		registro.setMnemonic(KeyEvent.VK_R);
		
		archivo.add(salir);
		
		registro.add(alta);
		registro.add(baja);
		
		ayuda.add(acerca);
		
		menu.add(archivo);
		menu.add(registro);
		menu.add(ayuda);
		
		this.setJMenuBar(menu);
		
	}
	
	/*
	 * Metodo que crea la ventana modal
	 */
	private void ventanaModal() {
		d = new JDialog();
		d.setSize(size.width,size.height);
		d.setTitle("Alta Reservas");
		d.setModal(true);
		d.setLayout(new BorderLayout());
		
		//Panel del titulo
		panel1 = new JPanel();
		panel1.setBackground(new Color(192,241,255));
		panel1.setBorder(new LineBorder(Color.black));
		titulo = new JLabel("Hotel Guadix");
		titulo.setFont(new Font("Monaco",Font.PLAIN,25));
		panel1.add(titulo);
		
		
		//Primer panel con los datos del usuario
		panel2 = new JPanel();
		panel2.setLayout(new GridLayout(7,2,10,10));
		panel2.setBackground(new Color(244,255,68));
		
		nombre = new JTextField();
		apellidos = new JTextField();
		try {
			MaskFormatter mask = new MaskFormatter("#########");
			MaskFormatter mask1 = new MaskFormatter("AAAAAAAAA");
			tlf = new JFormattedTextField(mask);
			dni = new JFormattedTextField(mask1);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		
		f_entrada = new JTextField();
		f_entrada.setText(Integer.toString(calendar.get(Calendar.DAY_OF_MONTH)));
		f_salida = new JTextField();
		calendar.add(Calendar.DAY_OF_MONTH,1);
		f_salida.setText(Integer.toString(calendar.get(Calendar.DAY_OF_MONTH)));
		
		n_dias = new JTextField();
		int dias = Integer.parseInt(f_salida.getText()) - Integer.parseInt(f_entrada.getText());
		n_dias.setText(Integer.toString(dias));
		
		nombre.setSize(150,50);
		apellidos.setSize(150,50);
		tlf.setSize(150,50);
		dni.setSize(150,50);
		f_entrada.setSize(150,50);
		f_salida.setSize(150,50);
		n_dias.setSize(150,50);
		
		lnombre = new JLabel("Nombre: ");
		lapellidos = new JLabel("Apellidos: ");
		ltlf = new JLabel("Tel�fono: ");
		ldni = new JLabel("DNI: ");
		lf_entrada = new JLabel("Fecha Entrada: ");
		lf_salida = new JLabel("Fecha Salida: ");
		ln_dias = new JLabel("N�mero de d�as totales: ");
		
		
		panel2.add(lnombre);
		panel2.add(nombre);
		
		panel2.add(lapellidos);
		panel2.add(apellidos);
		
		panel2.add(ltlf);
		panel2.add(tlf);
		
		panel2.add(ldni);
		panel2.add(dni);
		
		panel2.add(lf_entrada);
		panel2.add(f_entrada);
		
		panel2.add(lf_salida);
		panel2.add(f_salida);
		
		panel2.add(ln_dias);
		panel2.add(n_dias);
		
		
		//Segundo panel con los datos de la habitaci�n
		panel3 = new JPanel();
		panel3.setBackground(Color.cyan);
		panel3.setLayout(new GridLayout(7,2,10,10));
		String opciones[] = {"Simple","Doble","Suite"};
		tipo = new JComboBox<String>(opciones);
		SpinnerModel sm = new SpinnerNumberModel(0,0,50,1);
		n_habitaciones = new JSpinner(sm);
		nino = new JCheckBox();
		nino.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(nino.isSelected()) {
					edad_nino.setEnabled(true);
					extras.setEnabled(true);
				}else{
					edad_nino.setEnabled(false);
					extras.setEnabled(false);
				}
				
			}
		});
		SpinnerModel sm1 = new SpinnerNumberModel(0,0,14,1);
		edad_nino = new JSpinner(sm1);
		edad_nino.setEnabled(false);
		extras = new JTextField();
		extras.setEnabled(false);
		extras.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void focusGained(FocusEvent arg0) {
				// TODO Auto-generated method stub
				if((Integer) edad_nino.getValue()>=0 && (Integer) edad_nino.getValue()<3) {
					extras.setText("Cuna");
				}else if((Integer) edad_nino.getValue()>=4 && (Integer) edad_nino.getValue()<10) {
					extras.setText("Cama supletoria peque�a");
				}else if((Integer) edad_nino.getValue()>=10 && (Integer) edad_nino.getValue()<=14){
					extras.setText("Cama supletoria normal");
				}
			}
		});
		importe = new JTextField();
		importe.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void focusGained(FocusEvent arg0) {
				// TODO Auto-generated method stub
				if(n_dias.getText().length() == 0) {
					
				}else {
					importe.setText(precioFinal());
				}
				
			}
		});
		
		ltipo = new JLabel("Tipo de habitaci�n: ");
		lhabitaciones = new JLabel("N�mero de habitaciones: ");
		lnino = new JLabel("�Ni�os?");
		ledad = new JLabel("Edad de ni�os: ");
		lextras = new JLabel("Extras: ");
		limporte = new JLabel("Importe: ");
		
		Image img1 = new ImageIcon(getClass().getResource("../img/img1.jpg")).getImage();
		Image img2 = new ImageIcon(getClass().getResource("../img/img2.jpg")).getImage();
		Image img3 = new ImageIcon(getClass().getResource("../img/img3.jpg")).getImage();
		
		ImageIcon i1 = new ImageIcon(img1.getScaledInstance(250, 500,  java.awt.Image.SCALE_SMOOTH));
		ImageIcon i2 = new ImageIcon(img2.getScaledInstance(250, 500,  java.awt.Image.SCALE_SMOOTH));
		ImageIcon i3 = new ImageIcon(img3.getScaledInstance(250, 500,  java.awt.Image.SCALE_SMOOTH));
		
		lim1 = new JLabel();
		lim2 = new JLabel();
		lim3 = new JLabel();
		imagenes = new JLabel("Im�genes: ");
		
		lim1.setIcon(i1);
		lim2.setIcon(i2);
		lim3.setIcon(i3);
		
		panel3.add(ltipo);
		panel3.add(tipo);
		panel3.add(lhabitaciones);
		panel3.add(n_habitaciones);
		panel3.add(lnino);
		panel3.add(nino);
		panel3.add(ledad);
		panel3.add(edad_nino);
		panel3.add(lextras);
		panel3.add(extras);
		panel3.add(limporte);
		panel3.add(importe);
		
		Box caja = Box.createHorizontalBox();
		caja.add(lim1);
		caja.add(Box.createHorizontalStrut(10));
		caja.add(lim2);
		caja.add(Box.createHorizontalStrut(10));
		caja.add(lim3);
		panel3.add(imagenes);
		panel3.add(caja);
		
		
		//Cuarto panel con los datos formateados
		panel4 = new JPanel();
	
		tab = new JTabbedPane();
		Ppanel1 = new JPanel();
		
		

		Ppanel2 = new JPanel();
		
		
		tab.addTab("Datos usuario", Ppanel1);
		tab.addTab("Datos habitaci�n", Ppanel2);
		panel4.add(tab);
		panel4.setVisible(false);
		
		//Quinto panel con los botones
		panel5 = new JPanel();
		panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
		imprimir = new JButton("Imprimir a Documento");
		imprimir.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(comprobarDatos()) {
					panelF();
					panel4.setVisible(true);
				}else {
					panel4.setVisible(false);
					JOptionPane.showMessageDialog(null, "Primero rellena todos los campos.");
				}
					
			}
		});
		nuevo = new JButton("Nuevo");
		nuevo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				nombre.setText("");
				nombre.requestFocus();
				apellidos.setText("");
				dni.setText("");
				tlf.setText("");
				f_entrada.setText("");
				f_salida.setText("");
				n_dias.setText("");
			}
		});
		guardar = new JButton("Guardar");
		guardar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(comprobarDatos()) {
					JOptionPane.showMessageDialog(null, "Registro guardado.");
				}else {
					JOptionPane.showMessageDialog(null, "Debes completar todos los campos primero.");
				}
				
			}
		});
		panel5.add(imprimir);
		panel5.add(nuevo);
		panel5.add(guardar);
		
		d.add(panel1,BorderLayout.NORTH);
		d.add(panel2,BorderLayout.WEST);
		d.add(panel3,BorderLayout.CENTER);
		d.add(panel4,BorderLayout.EAST);
		d.add(panel5,BorderLayout.SOUTH);
		
		d.setVisible(true);
		
		
	}//Cierre del metodo
	
	/*
	 * Metodo que calcula el precio final y lo introduce en la etiqueta importe
	 */
	private String precioFinal() {
		int precio = 0;
		String habitacion = (String)tipo.getSelectedItem();
		int dias = Integer.parseInt(n_dias.getText());
		if(nino.isSelected()) {
			switch (habitacion) {
				case "Simple":
					precio = (50+20)*dias;
					break;
	
				case "Doble":
					precio = (75+20)*dias;
					break;
					
				case "Suite":
					precio = (125+20)*dias;
					break;
			}
		}else {
			switch (habitacion) {
			case "Simple":
				precio = (50)*dias;
				break;

			case "Doble":
				precio = (75)*dias;
				break;
			case "Suite":
				precio = (125)*dias;
				break;
			}
		}
		return Integer.toString(precio);
	}//Cierre del metodo
	
	/*
	 * Metodo que comprueba si los campos estan rellenados
	 */
	
	private boolean comprobarDatos() {
		
		if(nombre.getText().length() == 0) {
			return false;
		}else if(apellidos.getText().length() == 0) {
			return false;
		}else if(dni.getText().length() == 0) {
			return false;
		}else if(tlf.getText().length() == 0) {
			return false;
		}else if(f_entrada.getText().length() == 0) {
			return false;
		}else if(f_salida.getText().length() == 0) {
			return false;
		}else if((Integer) n_habitaciones.getValue() == 0) {
			return false;
		}else {
			return true;
		}		
	}//Cierre del metodo
	
	/*
	 * Metodo para crear el panel4 cuando se pulsa el bot�n imprimir 
	 */
	private void panelF() {
		Box caja1 = Box.createHorizontalBox();
		Box cajav = Box.createVerticalBox();
		cajav.add(new JLabel("Nombre: "));
		cajav.add(new JLabel("Apellidos: "));
		cajav.add(new JLabel("Dni: "));
		cajav.add(new JLabel("Telefono: "));
		cajav.add(new JLabel("Fecha entrada: "));
		cajav.add(new JLabel("Fecha salida: "));
		cajav.add(new JLabel("Numero de d�as: "));
		caja1.add(cajav);
		caja1.add(Box.createHorizontalStrut(10));
		Box cajav1 = Box.createVerticalBox();
		cajav1.add(new JLabel(nombre.getText()));
		cajav1.add(new JLabel(apellidos.getText()));
		cajav1.add(new JLabel(dni.getText()));
		cajav1.add(new JLabel(tlf.getText()));
		cajav1.add(new JLabel(f_entrada.getText()));
		cajav1.add(new JLabel(f_salida.getText()));
		cajav1.add(new JLabel(n_dias.getText()));
		caja1.add(cajav1);
		Ppanel1.add(caja1);
		
		Box caja2 = Box.createHorizontalBox();
		Box cajav2 = Box.createVerticalBox();
		cajav2.add(new JLabel("Tipo de habitaci�n: "));
		cajav2.add(new JLabel("N�mero de habitaciones: "));
		cajav2.add(new JLabel("�Ni�os?: "));
		if(nino.isSelected()) {
			cajav2.add(new JLabel("Edad de ni�os: "));
			cajav2.add(new JLabel("Extras: "));
		}
		cajav2.add(new JLabel("Importe: "));
		caja2.add(cajav2);
		caja2.add(Box.createHorizontalStrut(10));
		Box cajav3 = Box.createVerticalBox();
		cajav3.add(new JLabel(tipo.getSelectedItem().toString()));
		cajav3.add(new JLabel(n_habitaciones.getValue().toString()));
		
		if(nino.isSelected()) {
			cajav3.add(new JLabel("S�"));
			cajav3.add(new JLabel(edad_nino.getValue().toString()));
			cajav3.add(new JLabel(extras.getText()));
			cajav3.add(new JLabel(importe.getText()));
		}else {
			cajav3.add(new JLabel("No"));
			cajav3.add(new JLabel(precioFinal()));
		}
		
		caja2.add(cajav3);
		Ppanel2.add(caja2);
		
	}
}//Cierre de la clase
